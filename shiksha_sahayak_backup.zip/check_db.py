from app import create_app

app = create_app()

print("\n📋 ALL REGISTERED ROUTES:")
print("-" * 50)
for rule in sorted(app.url_map.iter_rules(), key=lambda r: r.rule):
    methods = ', '.join(sorted(rule.methods - {'HEAD', 'OPTIONS'}))
    print(f"{methods:10} {rule.rule}")